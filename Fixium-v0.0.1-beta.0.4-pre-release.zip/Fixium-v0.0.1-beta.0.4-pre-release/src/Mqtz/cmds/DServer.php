<?php

namespace Mqtz\cmds;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\Server;
use pocketmine\utils\Utils;
use pocketmine\network\protocol\Info as ProtocolInfo;
use raklib\RakLib;
use pocketmine\utils\TextFormat;
use pocketmine\plugin\Plugin;

class DServer implements CommandExecutor {

    /** @var Plugin */
    private $plugin;

    public function __construct(Plugin $plugin){
        $this->plugin = $plugin;
    }

    public function onCommand(CommandSender $sender, Command $command, $label, array $args) {
        if(strtolower($command->getName()) !== "dserver"){
            return false;
        }

        if(!$sender->hasPermission("fixium.command.dserver")){
            $sender->sendMessage(TextFormat::RED . "No tenés permiso para usar este comando.");
            return true;
        }

        $server = Server::getInstance();
$cpuUsage = floatval($server->getTickUsageAverage());

$lines = [
    TextFormat::BOLD . TextFormat::AQUA . "[ FIXIUM:ADVANCED INFO ]",
    TextFormat::GRAY . "Server Name: " . TextFormat::WHITE . $server->getName(),
    TextFormat::GRAY . "PMMP Version: " . TextFormat::GREEN . \pocketmine\VERSION,
    TextFormat::GRAY . "Codename: " . TextFormat::GREEN . \pocketmine\CODENAME,
    TextFormat::GRAY . "MCPE Version: " . TextFormat::GREEN . \pocketmine\MINECRAFT_VERSION,
    TextFormat::GRAY . "API Version: " . TextFormat::GREEN . \pocketmine\API_VERSION,
    TextFormat::GRAY . "Network Protocol: " . TextFormat::GREEN . ProtocolInfo::CURRENT_PROTOCOL,
    TextFormat::GRAY . "RakLib Version: " . TextFormat::GREEN . RakLib::VERSION,
    TextFormat::GRAY . "PHP Version: " . TextFormat::GREEN . PHP_VERSION,
    TextFormat::GRAY . "OS: " . TextFormat::GREEN . PHP_OS . " | " . Utils::getOS(),
    TextFormat::GRAY . "Online Players: " . TextFormat::GREEN . count($server->getOnlinePlayers()) . TextFormat::GRAY . "/" . TextFormat::GREEN . $server->getMaxPlayers(),
    TextFormat::GRAY . "Worlds Loaded: " . TextFormat::GREEN . count($server->getLevels()),
    TextFormat::GRAY . "Average TPS: " . TextFormat::GREEN . round($server->getTicksPerSecondAverage(), 2),
    TextFormat::GRAY . "Average CPU Usage: " . TextFormat::GREEN . (is_numeric($cpuUsage) ? round($cpuUsage, 2) . "%" : "N/A"),
    TextFormat::GRAY . "MOTD: " . TextFormat::GREEN . $server->getMotd(),
    TextFormat::GRAY . "Uptime: " . TextFormat::GREEN . $this->formatUptime($server->getUptime()),
    TextFormat::GRAY . "Fixium Version: " . TextFormat::GREEN . ($server->getPluginManager()->getPlugin("Fixium")->getDescription()->getVersion() ?? "Unknown"),
    TextFormat::GRAY . "Entities Loaded: " . TextFormat::GREEN . $this->getTotalEntities(),
    TextFormat::GRAY . "Active Chunks: " . TextFormat::GREEN . $this->getTotalChunks(),
    TextFormat::GRAY . "Plugins Loaded: " . TextFormat::GREEN . count($server->getPluginManager()->getPlugins()),
    TextFormat::GRAY . "Date: " . TextFormat::GREEN . date("Y-m-d H:i:s"),
    TextFormat::BOLD . TextFormat::AQUA . "-----------------------------"
];

        foreach($lines as $line){
            $sender->sendMessage($line);
        }

        return true;
    }

    private function formatUptime(int $seconds): string {
        $minutes = floor($seconds / 60);
        $hours = floor($minutes / 60);
        $minutes %= 60;
        $seconds %= 60;

        return "{$hours}h {$minutes}m {$seconds}s";
    }

    private function getTotalEntities(): int {
        $count = 0;
        foreach(Server::getInstance()->getLevels() as $world){
            $count += count($world->getEntities());
        }
        return $count;
    }

    private function getTotalChunks(): int {
        $count = 0;
        foreach(Server::getInstance()->getLevels() as $world){
            $count += count($world->getChunks());
        }
        return $count;
    }
}