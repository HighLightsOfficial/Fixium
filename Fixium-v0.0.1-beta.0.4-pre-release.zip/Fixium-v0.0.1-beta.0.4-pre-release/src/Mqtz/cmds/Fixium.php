<?php

namespace Mqtz\cmds;


use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\utils\TextFormat;
use Mqtz\Main;

class Fixium extends PluginBase implements CommandExecutor {

    /**
     * @param CommandSender $sender
     * @param Command $command
     * @param string $label
     * @param array $args
     * @return bool
     */
    public function onCommand(CommandSender $sender, Command $command, $label, array $args) {
        if(strtolower($command->getName()) === "fixium") {
            $sender->sendMessage(TextFormat::DARK_AQUA . "=== Fixium Plugin Info ===");
            $sender->sendMessage(TextFormat::RESET . "Plugin by HighLights");
            $sender->sendMessage("MCPE 0.15.10 PocketMine plugin for Optimization, bug fixes and debugging (v0.0.1-beta.0.4.pre-release).");
            $sender->sendMessage("");
            $sender->sendMessage("Useful Links:");
            $sender->sendMessage("- Fixium Graphic Maker (FGM): https://github.com/HighLightsOfficial/FGM/");
            $sender->sendMessage("- GitHub: https://github.com/orgs/HighLightsOfficial");
            $sender->sendMessage("- YouTube: https://youtube.com/@highlightscompany?feature=shared");
            $sender->sendMessage("");
            $sender->sendMessage(TextFormat::GRAY . "Thank you for using Fixium!");
            return true;
        }
        return false;
    }
}