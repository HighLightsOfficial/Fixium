<?php

namespace Mqtz\modules;

use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockUpdateEvent;
use Mqtz\tasks\LULTask;
use Mqtz\{Logger, Main};

class LightUpdateLimiter implements Listener {

    private static $lightUpdateCount = 0;
    private static $lightUpdateLimit = 100;

    public static function init() {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("Fixium");

        Server::getInstance()->getPluginManager()->registerEvents(new self(), $plugin);
        Server::getInstance()->getScheduler()->scheduleRepeatingTask(new LULTask($plugin), 1);

        Logger::log("LightUpdateLimiter initialized correctly.");
    }

    public static function canUpdateLight() {
        return self::$lightUpdateCount < self::$lightUpdateLimit;
    }

    public static function registerLightUpdate() {
        self::$lightUpdateCount++;
    }

    public static function resetLightCount() {
        self::$lightUpdateCount = 0;
    }

    /**
     * Evita que se acumulen demasiados eventos de luz
     */
    public function onBlockUpdate(BlockUpdateEvent $event) {
        if (!self::canUpdateLight()) {
            $event->cancel();
            return;
        }

        self::registerLightUpdate();
    }
}