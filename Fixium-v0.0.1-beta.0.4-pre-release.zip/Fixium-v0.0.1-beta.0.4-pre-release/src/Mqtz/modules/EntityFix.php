<?php

namespace Mqtz\modules;

use pocketmine\event\Listener;
use pocketmine\event\entity\EntitySpawnEvent;
use pocketmine\Player;
use Mqtz\Main;
use Mqtz\Logger;

class EntityFix implements Listener {

    public static function init() {
        $plugin = Main::getInstance();
        $config = $plugin->getConfig();

        if (!$config->getNested("fixes.entity-null-fix", true)) {
            Logger::log("EntityFix is disabled in config.");
            return;
        }

        $plugin->getServer()->getPluginManager()->registerEvents(new self(), $plugin);
    }

    public function onEntitySpawn(EntitySpawnEvent $event) {
        $entity = $event->getEntity();

        if ($entity === null) {
            $event->setCancelled(true);
            Logger::log("Cancelled spawn of null entity.");
            return;
        }

        if (method_exists($entity, "isClosed") && $entity->isClosed()) {
            $event->setCancelled(true);
            Logger::log("Cancelled spawn of closed entity.");
            return;
        }

        $x = $entity->getX();
        $y = $entity->getY();
        $z = $entity->getZ();

        if (is_nan($x) || is_nan($y) || is_nan($z)) {
            $event->setCancelled(true);
            Logger::log("Cancelled spawn of entity with invalid coordinates (NaN).");
        }
    }
}