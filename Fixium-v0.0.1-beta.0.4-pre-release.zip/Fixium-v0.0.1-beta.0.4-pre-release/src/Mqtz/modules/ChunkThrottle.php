<?php

namespace Mqtz\modules;

use pocketmine\level\Level;
use pocketmine\scheduler\Task;
use Mqtz\Logger;
use Mqtz\Main;

class ChunkThrottle {

    /** @var Main */
    private $plugin;

    /** @var int */
    private $maxChunksActive;

    /** @var int */
    private $maxChunksIdle;

    /** @var string[] */
    private $blacklist = [];

    /** @var array<string, bool> */
    private $worldStates = [];

    public function __construct(Main $plugin){
        $this->plugin = $plugin;

        $config = $plugin->getConfig()->get("chunk_throttle");
        $this->maxChunksActive = $config["max_active"] ?? 300;
        $this->maxChunksIdle = $config["max_idle"] ?? 75;
        $this->blacklist = array_map("strtolower", $config["blacklist"] ?? []);

        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(new class($this) extends Task {
            private $module;
            public function __construct(ChunkThrottle $module){
                $this->module = $module;
            }

            public function onRun($currentTick){
                $this->module->tick();
            }
        }, 40); 

        Logger::log("ChunkThrottle enabled. MaxChunks: Active={$this->maxChunksActive}, Idle={$this->maxChunksIdle}");
    }

    public function tick(){
        foreach($this->plugin->getServer()->getLevels() as $level){
            $name = strtolower($level->getFolderName());

            if(in_array($name, $this->blacklist)){
                continue;
            }

            $hasPlayers = count($level->getPlayers()) > 0;

            $prevState = $this->worldStates[$name] ?? null;
            $this->worldStates[$name] = $hasPlayers;

            if($prevState !== null && $prevState !== $hasPlayers){
                if($hasPlayers){
                    Logger::log("ChunkThrottle: World '{$name}' en modo activo.");
                } else {
                    Logger::log("ChunkThrottle: World '{$name}' en modo inactivo.");
                }
            }

            $limit = $hasPlayers ? $this->maxChunksActive : $this->maxChunksIdle;
            $this->applyLimit($level, $limit);
        }
    }

    private function applyLimit(Level $level, int $maxChunks){
    $chunks = $level->getChunks();
    if(count($chunks) <= $maxChunks){
        return;
    }

    $unloaded = 0;
    foreach($chunks as $chunk){
        if($unloaded >= (count($chunks) - $maxChunks)){
            break;
        }

        $x = $chunk->getX();
        $z = $chunk->getZ();

        $hasPlayerNearby = false;
        foreach($level->getPlayers() as $player){
            $px = $player->getFloorX() >> 4;
            $pz = $player->getFloorZ() >> 4;
            if(abs($px - $x) <= 2 && abs($pz - $z) <= 2){
                $hasPlayerNearby = true;
                break;
            }
        }

        if(!$hasPlayerNearby){
            $level->unloadChunk($x, $z, true);
            $unloaded++;
        }
    }

    if($unloaded > 0){
        Logger::log("ChunkThrottle: Unloaded {$unloaded} chunks from '{$level->getFolderName()}'.");
    }
}
}