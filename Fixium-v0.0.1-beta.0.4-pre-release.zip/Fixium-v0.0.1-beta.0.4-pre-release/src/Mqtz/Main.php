<?php

namespace Mqtz;

use pocketmine\plugin\PluginBase;
use Mqtz\Logger;
use Mqtz\modules\{WorldLoader, EntityFix, AutoCleaner, ChunkFreezeFix, TOD, FixiumProfiler, FixiumTickLimiter, SoftViewDistanceLimiter, ChunkThrottle, LightUpdateLimiter};
use Mqtz\cmds\{Fixium, Worlds, PluginCheck, PluginRestarter, DServer};

class Main extends PluginBase {

    private static $instance;

    public function onLoad() {
        self::$instance = $this;
    }

    public function onEnable() {
    @mkdir($this->getDataFolder() . "logs");
    @mkdir($this->getDataFolder() . "resources");

    $this->saveResource("config.yml");

    Logger::log("Fixium has been successfully enabled.(v0.0.1-beta.0.4)");
    WorldLoader::loadWorlds();
    EntityFix::init();
    AutoCleaner::init();
    ChunkFreezeFix::init();
    TOD::init($this);
    FixiumProfiler::init($this);
    LightUpdateLimiter::init($this);

    new FixiumTickLimiter($this);
    new SoftViewDistanceLimiter($this);
    new ChunkThrottle($this);

    $this->getCommand("fixium")->setExecutor(new Fixium());
    $this->getCommand("worlds")->setExecutor(new Worlds($this));
    $this->getCommand("plcheck")->setExecutor(new PluginCheck($this));
    $this->getCommand("fxm")->setExecutor(new PluginRestarter($this));
    $this->getCommand("dserver")->setExecutor(new DServer($this));
}

    public function onDisable() {
        Logger::log("Fixium has been disabled.");
    }
    public static function getInstance() {
        return self::$instance;
    }
}