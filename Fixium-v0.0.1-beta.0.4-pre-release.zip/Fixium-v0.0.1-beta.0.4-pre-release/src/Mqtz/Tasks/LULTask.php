<?php

namespace Mqtz\tasks;

use pocketmine\scheduler\PluginTask;
use Mqtz\modules\LightUpdateLimiter;

class LULTask extends PluginTask {

    public function __construct(\pocketmine\plugin\Plugin $plugin) {
        parent::__construct($plugin);
    }

    public function onRun($tick) {
        LightUpdateLimiter::resetLightCount();
    }
}