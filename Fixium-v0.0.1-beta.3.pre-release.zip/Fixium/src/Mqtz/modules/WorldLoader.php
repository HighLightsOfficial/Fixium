<?php

namespace Mqtz\modules;

use Mqtz\Main;
use Mqtz\Logger;

class WorldLoader {

    public static function loadWorlds() {
        $plugin = Main::getInstance();
        $config = $plugin->getConfig();

        if (!$config->getNested("settings.auto-world-load", true)) {
            Logger::log("Auto world loading is disabled in config.");
            return;
        }

        $worldFolder = $plugin->getServer()->getDataPath() . "worlds/";
        $loaded = 0;

        if (!is_dir($worldFolder)) {
            Logger::log("World folder not found.");
            return;
        }

        $worlds = scandir($worldFolder);
        foreach ($worlds as $worldName) {
            if ($worldName === "." || $worldName === "..") continue;

            $worldPath = $worldFolder . $worldName;
            if (is_dir($worldPath) && file_exists($worldPath . "/level.dat")) {
                if (!$plugin->getServer()->isLevelLoaded($worldName)) {
                    $plugin->getServer()->loadLevel($worldName);
                    $loaded++;
                }
            }
        }

        if ($loaded > 0) {
            Logger::log("Successfully loaded $loaded world(s).");
        } else {
            Logger::log("No additional worlds were loaded.");
        }
    }
}