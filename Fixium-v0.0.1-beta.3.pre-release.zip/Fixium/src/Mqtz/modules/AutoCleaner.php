<?php

namespace Mqtz\modules;

use Mqtz\Main;
use Mqtz\Logger;
use Mqtz\Tasks\AutoCleanerT;

class AutoCleaner {

    public static function init() {
        $plugin = Main::getInstance();
        $config = $plugin->getConfig();

        if (!$config->getNested("optimize.auto-cleanup", true)) {
            Logger::log("AutoCleaner is disabled in config.");
            return;
        }

        $interval = intval($config->getNested("optimize.cleanup-interval", 300));
        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(new AutoCleanerT(), $interval * 20);
    }
}