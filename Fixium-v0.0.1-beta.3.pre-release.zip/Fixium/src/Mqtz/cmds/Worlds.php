<?php

namespace Mqtz\cmds;


use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\utils\TextFormat;

class Worlds implements CommandExecutor {

    /** @var \pocketmine\plugin\PluginBase */
    private $plugin;

    public function __construct($plugin){
        $this->plugin = $plugin;
    }

    public function onCommand(CommandSender $sender, Command $command, $label, array $args){
        if(strtolower($command->getName()) === "worlds"){

            $server = $this->plugin->getServer();
            $dataPath = $server->getDataPath() . "worlds/";
            $loadedLevels = $server->getLevels();

            $folders = array_filter(scandir($dataPath), function($f) use ($dataPath){
                return $f !== '.' && $f !== '..' && is_dir($dataPath . $f);
            });

            if(count($folders) === 0){
                $sender->sendMessage(TextFormat::RED . "No worlds found on disk.");
                return true;
            }

            $sender->sendMessage(TextFormat::DARK_GREEN . "=== Worlds Info ===");

            foreach($folders as $folderName){
                $level = $server->getLevelByName($folderName);
                $loaded = ($level !== null);
                $status = $loaded ? TextFormat::GREEN . "Loaded" : TextFormat::RED . "Unloaded";

                $sizeBytes = $this->getFolderSize($dataPath . $folderName);
                $sizeMB = round($sizeBytes / 1048576, 2);

                $loadedChunks = $loaded ? count($level->getChunks()) : 0;
                $playersCount = $loaded ? count($level->getPlayers()) : 0;

                $sender->sendMessage(TextFormat::AQUA . "World: " . $folderName);
                $sender->sendMessage(" - Status: " . $status);
                $sender->sendMessage(" - Size on Disk: " . $sizeMB . " MB");
                if($loaded){
                    $sender->sendMessage(" - Loaded Chunks: " . $loadedChunks);
                    $sender->sendMessage(" - Players: " . $playersCount);
                }
                $sender->sendMessage("");
            }
            return true;
        }
        return false;
    }

    private function getFolderSize($path){
        $size = 0;
        if(!is_dir($path)){
            return 0;
        }
        foreach(new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($path)) as $file){
            if($file->isFile()){
                $size += $file->getSize();
            }
        }
        return $size;
    }
}