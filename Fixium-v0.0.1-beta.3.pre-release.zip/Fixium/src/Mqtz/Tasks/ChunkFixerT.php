<?php

namespace Mqtz\Tasks;

use pocketmine\scheduler\Task;
use pocketmine\level\Level;
use pocketmine\Server;
use Mqtz\Logger;

class ChunkFixerT extends Task {

    public function onRun($currentTick) {
        $beforeReal = memory_get_usage(false);
        $beforeAlloc = memory_get_usage(true);

        $unloaded = 0;

        foreach (Server::getInstance()->getLevels() as $level) {
            foreach ($level->getChunks() as $chunk) {
                $chunkX = $chunk->getX();
                $chunkZ = $chunk->getZ();

                if ($level->isChunkLoaded($chunkX, $chunkZ)) {
                    if (count($level->getChunkPlayers($chunkX, $chunkZ)) === 0) {
                        $level->unloadChunk($chunkX, $chunkZ, true);
                        $unloaded++;
                    }
                }
            }
        }

        gc_collect_cycles();

        $afterReal = memory_get_usage(false);
        $afterAlloc = memory_get_usage(true);

        $freedReal = round(($beforeReal - $afterReal) / 1024 / 1024, 2);
        $freedAlloc = round(($beforeAlloc - $afterAlloc) / 1024 / 1024, 2);

        Logger::log("ChunkFreezeFix unloaded $unloaded unused chunk(s).");
        Logger::log("Memory freed (real): $freedReal MB (Before: " . round($beforeReal / 1024 / 1024, 2) . " MB | After: " . round($afterReal / 1024 / 1024, 2) . " MB)");
        Logger::log("Memory freed (allocated): $freedAlloc MB (Before: " . round($beforeAlloc / 1024 / 1024, 2) . " MB | After: " . round($afterAlloc / 1024 / 1024, 2) . " MB)");
        Logger::log("Note: PHP may retain allocated memory after chunk unload. Actual memory freed could be higher.");
    }
}