<?php
/*
 * ------------------------------------------------------------
 * Fixium - Minecraft PE Server Optimizer & Utilities Plugin
 * ------------------------------------------------------------
 *
 * Project:       Fixium
 * Version:       0.0.1-beta.0.5
 * Author:        HighLightsOfficial
 * GitHub:        https://github.com/HighLightsOfficial/Fixium
 * Description:   Performance enhancements, world/entity fixes, and server utilities
 * License:       MIT License (https://opensource.org/licenses/MIT)
 *                Permission is hereby granted, free of charge, to any person
 *                obtaining a copy of this software and associated documentation
 *                files (the "Software"), to deal in the Software without
 *                restriction, including without limitation the rights to use,
 *                copy, modify, merge, publish, distribute, sublicense, and/or
 *                sell copies of the Software, subject to the conditions in the
 *                LICENSE file.
 * ------------------------------------------------------------
 */
namespace Mqtz;

use pocketmine\plugin\PluginBase;
use Mqtz\Logger;
use Mqtz\modules\{WorldLoader, EntityFix, AutoCleaner, ChunkFreezeFix, TOD, FixiumProfiler, FixiumTickLimiter, SoftViewDistanceLimiter, ChunkThrottle, LightUpdateLimiter, LagCommandQueue};
use Mqtz\cmds\{Fixium, Worlds, PluginCheck, PluginRestarter, DServer};
use pocketmine\utils\Config;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;

class Main extends PluginBase implements Listener {

    private static $instance;
    private $latestRelease = null;

    public function onEnable() {
        @mkdir($this->getDataFolder() . "logs");
        @mkdir($this->getDataFolder() . "resources");

        $this->saveResource("config.yml");
        $this->saveResource("update-check.yml");

        Logger::info("Fixium has been successfully enabled.(0.0.1-beta.0.5.pre-release)");

        WorldLoader::loadWorlds();
        EntityFix::init();
        AutoCleaner::init();
        ChunkFreezeFix::init();
        TOD::init($this);
        FixiumProfiler::init($this);
        LightUpdateLimiter::init($this);
        LagCommandQueue::init($this);
        new FixiumTickLimiter($this);
        new SoftViewDistanceLimiter($this);
        new ChunkThrottle($this);

        $this->getCommand("fixium")->setExecutor(new Fixium());
        $this->getCommand("worlds")->setExecutor(new Worlds($this));
        $this->getCommand("plcheck")->setExecutor(new PluginCheck($this));
        $this->getCommand("fxm")->setExecutor(new PluginRestarter($this));
        $this->getCommand("dserver")->setExecutor(new DServer($this));

        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        $this->checkGithubRelease();
    }

    public function onJoin(PlayerJoinEvent $event) {
        $player = $event->getPlayer();
        if ($this->latestRelease !== null) {
            $player->sendMessage("[Fixium] §eNew release available! Your version: §a" . $this->getDescription()->getVersion() . "§e | Latest: §a" . $this->latestRelease["tag"] . "§e | §b" . $this->latestRelease["url"]);
        }
    }

    private function checkGithubRelease() {
        Logger::info("Finding new releases...");

        $repo = "HighLightsOfficial/Fixium";
        $url = "https://api.github.com/repos/$repo/tags";
        $userAgent = "FixiumServerPlugin";

        if (!function_exists("curl_version")) {
            Logger::warning("cURL is not available, cannot check GitHub releases.");
            return;
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $json = @curl_exec($ch);
        $curlError = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($json === false || $httpCode >= 400) {
            Logger::warning("Could not fetch release info from GitHub (cURL). HTTP code: " . ($httpCode ?: "N/A") . " Error: " . $curlError);
            return;
        }

        $tags = @json_decode($json, true);
        if (!is_array($tags) || empty($tags)) {
            Logger::warning("Could not decode tags from GitHub (invalid JSON or empty).");
            return;
        }

        $latestTag = ltrim(trim($tags[0]["name"]), "vV ");
        $currentVersion = ltrim(trim($this->getDescription()->getVersion()), "vV ");
        $htmlUrl = "https://github.com/$repo/tree/" . $tags[0]["name"];

        if (version_compare($latestTag, $currentVersion, ">")) {
            Logger::info("New release found on GitHub! Your version: $currentVersion | New version: $latestTag | $htmlUrl");
            $this->latestRelease = ["tag" => $latestTag, "url" => $htmlUrl];
        } else {
            Logger::info("No new releases found, you are using the latest version of Fixium! (Current: $currentVersion)");
            $this->latestRelease = null;
        }
    }
}