<?php
/*
 * ------------------------------------------------------------
 * Fixium - Minecraft PE Server Optimizer & Utilities Plugin
 * ------------------------------------------------------------
 *
 * Project:       Fixium
 * Version:       0.0.1-beta.0.5
 * Author:        HighLightsOfficial
 * GitHub:        https://github.com/HighLightsOfficial/Fixium
 * Description:   Performance enhancements, world/entity fixes, and server utilities
 * License:       MIT License (https://opensource.org/licenses/MIT)
 *                Permission is hereby granted, free of charge, to any person
 *                obtaining a copy of this software and associated documentation
 *                files (the "Software"), to deal in the Software without
 *                restriction, including without limitation the rights to use,
 *                copy, modify, merge, publish, distribute, sublicense, and/or
 *                sell copies of the Software, subject to the conditions in the
 *                LICENSE file.
 * ------------------------------------------------------------
 */

namespace Mqtz\modules;

use pocketmine\event\Listener;
use pocketmine\event\entity\EntitySpawnEvent;
use pocketmine\Player;
use Mqtz\Main;
use Mqtz\Logger;

class EntityFix implements Listener {

    public static function init() {
        $plugin = Main::getInstance();
        $config = $plugin->getConfig();

        if (!$config->getNested("fixes.entity-null-fix", true)) {
            Logger::log("EntityFix is disabled in config.");
            return;
        }

        $plugin->getServer()->getPluginManager()->registerEvents(new self(), $plugin);
    }

    public function onEntitySpawn(EntitySpawnEvent $event) {
        $entity = $event->getEntity();

        if ($entity === null) {
            $event->setCancelled(true);
            Logger::warning("Cancelled spawn of null entity.");
            return;
        }

        if (method_exists($entity, "isClosed") && $entity->isClosed()) {
            $event->setCancelled(true);
            Logger::info("Cancelled spawn of closed entity.");
            return;
        }

        $x = $entity->getX();
        $y = $entity->getY();
        $z = $entity->getZ();

        if (is_nan($x) || is_nan($y) || is_nan($z)) {
            $event->setCancelled(true);
            Logger::warning("Cancelled spawn of entity with invalid coordinates (NaN).");
        }
    }
}