<?php
/*
 * ------------------------------------------------------------
 * Fixium - Minecraft PE Server Optimizer & Utilities Plugin
 * ------------------------------------------------------------
 *
 * Project:       Fixium
 * Version:       0.0.1-beta.0.5
 * Author:        HighLightsOfficial
 * GitHub:        https://github.com/HighLightsOfficial/Fixium
 * Description:   Performance enhancements, world/entity fixes, and server utilities
 * License:       MIT License (https://opensource.org/licenses/MIT)
 *                Permission is hereby granted, free of charge, to any person
 *                obtaining a copy of this software and associated documentation
 *                files (the "Software"), to deal in the Software without
 *                restriction, including without limitation the rights to use,
 *                copy, modify, merge, publish, distribute, sublicense, and/or
 *                sell copies of the Software, subject to the conditions in the
 *                LICENSE file.
 * ------------------------------------------------------------
 */

namespace Mqtz\modules;

use pocketmine\level\Level;
use pocketmine\scheduler\Task;
use Mqtz\Logger;
use Mqtz\Main;

class FixiumTickLimiter {

    /** @var Fixium */
    private $plugin;

    /** @var int */
    private $intervalIdle;

    /** @var int */
    private $intervalActive;

    /** @var array<string, bool> */
    private $worldStates = [];

    /** @var string[] */
    private $blacklist = [];

    public function __construct(Main $plugin){
        $this->plugin = $plugin;

        $config = $plugin->getConfig()->get("tick_limiter");
        $this->intervalIdle = $config["idle"] ?? 10;
        $this->intervalActive = $config["active"] ?? 1;
        $this->blacklist = array_map("strtolower", $config["blacklist"] ?? []);

        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(new class($this) extends Task {
            private $module;
            public function __construct(FixiumTickLimiter $module){
                $this->module = $module;
            }

            public function onRun($currentTick){
                $this->module->tick();
            }
        }, 20);

        Logger::log("FixiumTickLimiter enabled. Idle interval: {$this->intervalIdle} ticks. Active interval: {$this->intervalActive} tick.");
    }

    public function tick(){
        foreach($this->plugin->getServer()->getLevels() as $level){
            $name = strtolower($level->getFolderName());

            
            if(in_array($name, $this->blacklist)){
                continue;
            }

            $hasPlayers = count($level->getPlayers()) > 0;

            $prevState = $this->worldStates[$name] ?? null;
            $this->worldStates[$name] = $hasPlayers;

            if($prevState !== null && $prevState !== $hasPlayers){
                if($hasPlayers){
                    Logger::info("World '{$name}' resumed active mode (players joined).");
                } else {
                    Logger::info("World '{$name}' entered idle mode (no players).");
                }
            }

            $ticks = $hasPlayers ? $this->intervalActive : $this->intervalIdle;
            $this->simulateWorld($level, $ticks);
        }
    }

    private function simulateWorld(Level $level, $ticks){
        for($i = 0; $i < $ticks; $i++){
            $level->doTick(1);
        }
    }
}