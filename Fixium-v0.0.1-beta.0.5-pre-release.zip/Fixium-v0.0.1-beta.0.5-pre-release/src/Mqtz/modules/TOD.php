<?php
/*
 * ------------------------------------------------------------
 * Fixium - Minecraft PE Server Optimizer & Utilities Plugin
 * ------------------------------------------------------------
 *
 * Project:       Fixium
 * Version:       0.0.1-beta.0.5
 * Author:        HighLightsOfficial
 * GitHub:        https://github.com/HighLightsOfficial/Fixium
 * Description:   Performance enhancements, world/entity fixes, and server utilities
 * License:       MIT License (https://opensource.org/licenses/MIT)
 *                Permission is hereby granted, free of charge, to any person
 *                obtaining a copy of this software and associated documentation
 *                files (the "Software"), to deal in the Software without
 *                restriction, including without limitation the rights to use,
 *                copy, modify, merge, publish, distribute, sublicense, and/or
 *                sell copies of the Software, subject to the conditions in the
 *                LICENSE file.
 * ------------------------------------------------------------
 */

namespace Mqtz\modules;

use Mqtz\Tasks\TODTask;
use Mqtz\Main;

class TOD {

    public static function init(Main $plugin) {
        $plugin->getServer()->getScheduler()->scheduleDelayedTask(new TODTask($plugin), 20);
    }
}