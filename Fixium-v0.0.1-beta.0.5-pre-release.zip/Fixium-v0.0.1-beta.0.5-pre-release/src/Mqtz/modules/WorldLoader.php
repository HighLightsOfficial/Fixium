<?php
/*
 * ------------------------------------------------------------
 * Fixium - Minecraft PE Server Optimizer & Utilities Plugin
 * ------------------------------------------------------------
 *
 * Project:       Fixium
 * Version:       0.0.1-beta.0.5
 * Author:        HighLightsOfficial
 * GitHub:        https://github.com/HighLightsOfficial/Fixium
 * Description:   Performance enhancements, world/entity fixes, and server utilities
 * License:       MIT License (https://opensource.org/licenses/MIT)
 *                Permission is hereby granted, free of charge, to any person
 *                obtaining a copy of this software and associated documentation
 *                files (the "Software"), to deal in the Software without
 *                restriction, including without limitation the rights to use,
 *                copy, modify, merge, publish, distribute, sublicense, and/or
 *                sell copies of the Software, subject to the conditions in the
 *                LICENSE file.
 * ------------------------------------------------------------
 */

namespace Mqtz\modules;

use Mqtz\Main;
use Mqtz\Logger;

class WorldLoader {

    public static function loadWorlds() {
        $plugin = Main::getInstance();
        $config = $plugin->getConfig();

        if (!$config->getNested("settings.auto-world-load", true)) {
            Logger::log("Auto world loading is disabled in config.");
            return;
        }

        $worldFolder = $plugin->getServer()->getDataPath() . "worlds/";
        $loaded = 0;

        if (!is_dir($worldFolder)) {
            Logger::warning("World folder not found.");
            return;
        }

        $worlds = scandir($worldFolder);
        foreach ($worlds as $worldName) {
            if ($worldName === "." || $worldName === "..") continue;

            $worldPath = $worldFolder . $worldName;
            if (is_dir($worldPath) && file_exists($worldPath . "/level.dat")) {
                if (!$plugin->getServer()->isLevelLoaded($worldName)) {
                    $plugin->getServer()->loadLevel($worldName);
                    $loaded++;
                }
            }
        }

        if ($loaded > 0) {
            Logger::info("Successfully loaded $loaded world(s).");
        } else {
            Logger::info("No additional worlds were loaded.");
        }
    }
}