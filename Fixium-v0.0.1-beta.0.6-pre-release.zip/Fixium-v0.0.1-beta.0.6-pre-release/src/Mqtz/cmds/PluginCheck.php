<?php
/*
 * ------------------------------------------------------------
 * Fixium - Minecraft PE Server Optimizer & Utilities Plugin
 * ------------------------------------------------------------
 *
 * Project:       Fixium
 * Version:       0.0.1-beta.0.5
 * Author:        HighLightsOfficial
 * GitHub:        https://github.com/HighLightsOfficial/Fixium
 * Description:   Performance enhancements, world/entity fixes, and server utilities
 * License:       MIT License (https://opensource.org/licenses/MIT)
 *                Permission is hereby granted, free of charge, to any person
 *                obtaining a copy of this software and associated documentation
 *                files (the "Software"), to deal in the Software without
 *                restriction, including without limitation the rights to use,
 *                copy, modify, merge, publish, distribute, sublicense, and/or
 *                sell copies of the Software, subject to the conditions in the
 *                LICENSE file.
 * ------------------------------------------------------------
 */

namespace Mqtz\cmds;


use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\utils\TextFormat;
use pocketmine\plugin\Plugin;

class PluginCheck implements CommandExecutor {

    /** @var \pocketmine\plugin\PluginManager */
    private $pluginManager;

    /** @var \pocketmine\plugin\PluginBase */
    private $plugin;

    public function __construct($plugin){
        $this->plugin = $plugin;
        $this->pluginManager = $plugin->getServer()->getPluginManager();
    }

    public function onCommand(CommandSender $sender, Command $command, $label, array $args){
        if(strtolower($command->getName()) === "plcheck"){

            if(count($args) === 0){
                $sender->sendMessage(TextFormat::RED . "Usage: /plcheck <pluginName|--all>");
                return true;
            }

            $arg = strtolower($args[0]);

            if($arg === "--all"){
                $plugins = $this->pluginManager->getPlugins();
                if(empty($plugins)){
                    $sender->sendMessage(TextFormat::RED . "No plugins found.");
                    return true;
                }
                $sender->sendMessage(TextFormat::DARK_GREEN . "=== Plugins Status ===");
                foreach($plugins as $plugin){
                    $this->sendPluginInfo($sender, $plugin);
                }
                return true;
            } else {
                $plugin = $this->pluginManager->getPlugin($args[0]);
                if($plugin === null){
                    $sender->sendMessage(TextFormat::RED . "Plugin '{$args[0]}' not found.");
                    return true;
                }
                $sender->sendMessage(TextFormat::DARK_GREEN . "=== Plugin Info ===");
                $this->sendPluginInfo($sender, $plugin);
                return true;
            }
        }
        return false;
    }

    private function sendPluginInfo(CommandSender $sender, Plugin $plugin){
        $name = $plugin->getName();
        $version = $plugin->getDescription()->getVersion() ?? "Unknown";
        $author = implode(", ", $plugin->getDescription()->getAuthors() ?? ["Unknown"]);
        $description = $plugin->getDescription()->getDescription() ?? "No description";

        $isEnabled = $plugin->isEnabled();
        $status = $isEnabled ? TextFormat::GREEN . "Active" : TextFormat::RED . "Inactive";

        $pluginPath = $this->plugin->getServer()->getPluginPath() . DIRECTORY_SEPARATOR . $name;

        $sizeBytes = $this->getFolderSize($pluginPath);
        $sizeMB = round($sizeBytes / 1048576, 2);

        $memoryUsage = $isEnabled ? $this->getPluginMemoryUsage($plugin) : 0;
        $memoryMB = round($memoryUsage / 1048576, 2);

        $sender->sendMessage(TextFormat::AQUA . "Plugin: " . $name);
        $sender->sendMessage(" - Version: " . $version);
        $sender->sendMessage(" - Author(s): " . $author);
        $sender->sendMessage(" - Description: " . $description);
        $sender->sendMessage(" - Status: " . $status);
        $sender->sendMessage(" - Folder Size: " . $sizeMB . " MB");
        if($isEnabled){
            $sender->sendMessage(" - Approx. Memory Usage: " . $memoryMB . " MB");
        }
        $sender->sendMessage("");
    }

    private function getFolderSize($path){
        $size = 0;
        if(!is_dir($path)){
            return 0;
        }
        foreach(new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($path)) as $file){
            if($file->isFile()){
                $size += $file->getSize();
            }
        }
        return $size;
    }

    private function getPluginMemoryUsage(Plugin $plugin){
       // PocketMine doesn't give exact memory per plugin, so we approximate by the total current usage (in bytes)
        return memory_get_usage(true);
    }
}