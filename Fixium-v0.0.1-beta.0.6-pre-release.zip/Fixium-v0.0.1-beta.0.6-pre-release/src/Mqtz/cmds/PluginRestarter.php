<?php
/*
 * ------------------------------------------------------------
 * Fixium - Minecraft PE Server Optimizer & Utilities Plugin
 * ------------------------------------------------------------
 *
 * Project:       Fixium
 * Version:       0.0.1-beta.0.6
 * Author:        HighLightsOfficial, Mateo Collar
 * GitHub:        https://github.com/HighLightsOfficial/Fixium
 * Description:   Performance enhancements, world/entity fixes, and server utilities
 * License:       MIT License (https://opensource.org/licenses/MIT)
 * ------------------------------------------------------------
 */

namespace Mqtz\cmds;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\plugin\Plugin;
use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat;
use Mqtz\Main;
use Mqtz\Logger;

class PluginRestarter implements CommandExecutor {

    var $plugin;
    var $interval;
    var $maxMemory;
    var $alerts;

    function __construct($main){
        $this->plugin = $main;

        $config = $main->getConfig()->get("plugin_restarter");

        $this->interval = isset($config["check_interval_ticks"]) ? $config["check_interval_ticks"] : 600;
        $this->maxMemory = isset($config["max_plugin_memory_mb"]) ? $config["max_plugin_memory_mb"] : 5;
        $this->alerts = isset($config["enable_alerts"]) ? $config["enable_alerts"] : true;

        $main->getServer()->getScheduler()->scheduleRepeatingTask(new class($this) extends Task {
            var $mod;
            function __construct($mod){ $this->mod = $mod; }
            function onRun($tick){ $this->mod->checkPlugins(); }
        }, $this->interval);

        if ($main->getConfig()->get("log-activated-modules", true)) {
            Logger::info("Module loaded: PluginRestarter. Threshold: {$this->maxMemory}MB, Interval: {$this->interval} ticks.");
        }
    }

    function checkPlugins(){
        $plugins = $this->plugin->getServer()->getPluginManager()->getPlugins();
        foreach($plugins as $plugin){
            $name = $plugin->getName();
            if($name === "Fixium"){ continue; }

            $memory = $this->estimateMemory($plugin);
            $enabled = $plugin->isEnabled();

            if(!$enabled or $memory > $this->maxMemory){
                Logger::warning("PluginRestarter: Plugin '$name' is " . (!$enabled ? "DISABLED" : "over memory ({$memory}MB)") . ".");

                if($this->alerts){
                    foreach($this->plugin->getServer()->getOnlinePlayers() as $p){
                        if($p->hasPermission("fxm.alert")){
                            $p->sendMessage("§b[Fixium]§r Plugin §c{$name}§r may be overloaded. Use §e/fxm -r {$name}§r to reload.");
                        }
                    }
                }
            }
        }
    }

    function estimateMemory($plugin){
        $folder = $plugin->getDataFolder();
        if(!is_dir($folder)){ return 0; }

        $total = 0;
        $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($folder));
        foreach($iterator as $file){
            if($file->isFile()){
                $total += $file->getSize();
            }
        }

        return round($total / 1024 / 1024, 2);
    }

    function onCommand(CommandSender $sender, Command $command, $label, array $args){
        if(strtolower($command->getName()) !== "fxm"){
            return false;
        }

        if(count($args) === 0){
            $sender->sendMessage(TextFormat::YELLOW . "Use: /fxm -r (--a|pluginName)");
            return true;
        }

        if($args[0] !== "-r"){
            $sender->sendMessage(TextFormat::RED . "Unknown argument: " . $args[0]);
            return true;
        }

        if(!isset($args[1])){
            $sender->sendMessage(TextFormat::RED . "Missing plugin name or --a");
            return true;
        }

        if($args[1] === "--a"){
            foreach($this->plugin->getServer()->getPluginManager()->getPlugins() as $pl){
                if($pl->getName() !== "Fixium"){
                    $this->plugin->getServer()->getPluginManager()->disablePlugin($pl);
                    $this->plugin->getServer()->getPluginManager()->enablePlugin($pl);
                    if ($this->plugin->getConfig()->get("log-activated-modules", true)) {
                        Logger::info("PluginRestarter: Reloaded plugin '{$pl->getName()}'");
                    }
                }
            }
            $sender->sendMessage(TextFormat::GREEN . "All plugins reloaded.");
            return true;
        }

        $target = $args[1];
        $pl = $this->plugin->getServer()->getPluginManager()->getPlugin($target);
        if($pl === null){
            $sender->sendMessage(TextFormat::RED . "Plugin '{$target}' not found.");
            return true;
        }

        $this->plugin->getServer()->getPluginManager()->disablePlugin($pl);
        $this->plugin->getServer()->getPluginManager()->enablePlugin($pl);
        if ($this->plugin->getConfig()->get("log-activated-modules", true)) {
            Logger::info("PluginRestarter: Reloaded plugin '{$target}'");
        }

        $sender->sendMessage(TextFormat::GREEN . "Plugin '{$target}' reloaded.");
        return true;
    }
}