<?php
/*
 * ------------------------------------------------------------
 * Fixium - Minecraft PE Server Optimizer & Utilities Plugin
 * ------------------------------------------------------------
 *
 * Project:       Fixium
 * Version:       0.0.1-beta.0.6
 * Author:        HighLightsOfficial, Mateo Collar
 * GitHub:        https://github.com/HighLightsOfficial/Fixium
 * Description:   Performance enhancements, world/entity fixes, and server utilities
 * License:       MIT License (https://opensource.org/licenses/MIT)
 * ------------------------------------------------------------
 */
namespace Mqtz\modules;

use Mqtz\Main;
use Mqtz\Logger;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerPreLoginEvent;

class AntiDDoSMitigator implements Listener {

    private static $connections = [];
    private static $blacklist = [];
    private static $maxPerSecond = 15;
    private static $enabled = false;
    private static $autoBlacklist = true;
    private static $blacklistFile;

    public static function init(Main $plugin) {
        $config = $plugin->getConfig();

        self::$enabled = $config->getNested("settings.anti-ddos.enabled", false);
        self::$maxPerSecond = $config->getNested("settings.anti-ddos.max-per-second", 15);
        self::$autoBlacklist = $config->getNested("settings.anti-ddos.auto-blacklist", true);

        self::$blacklistFile = $plugin->getDataFolder() . "blacklist.yml";
        if (file_exists(self::$blacklistFile)) {
            self::$blacklist = yaml_parse_file(self::$blacklistFile) ?: [];
        }

        if (self::$enabled) {
            $plugin->getServer()->getPluginManager()->registerEvents(new self(), $plugin);
        }

        if ($config->get("log-activated-modules", true) && self::$enabled) {
            Logger::info("Module loaded: AntiDDoS Mitigator");
        }
    }

    public function onPreLogin(PlayerPreLoginEvent $event) {
        if (!self::$enabled) return;

        $ip = $event->getPlayer()->getAddress();

        if (in_array($ip, self::$blacklist)) {
            $event->setCancelled();
            return;
        }

        $time = microtime(true);
        self::$connections[$ip][] = $time;

        self::$connections[$ip] = array_filter(self::$connections[$ip], function($t) use ($time) {
            return ($time - $t) <= 1;
        });

        if (count(self::$connections[$ip]) > self::$maxPerSecond) {
            $event->setCancelled();
            $event->getPlayer()->kick("§7( §eFixium§7 ) Too many connections/sec.");

            if (self::$autoBlacklist) {
                self::$blacklist[] = $ip;
                yaml_emit_file(self::$blacklistFile, self::$blacklist);
            }

            Logger::warning("Blocked $ip due to excessive connections.");
        }
    }
}