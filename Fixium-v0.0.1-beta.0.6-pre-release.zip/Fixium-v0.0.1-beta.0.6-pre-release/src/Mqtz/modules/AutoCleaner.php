<?php
/*
 * ------------------------------------------------------------
 * Fixium - Minecraft PE Server Optimizer & Utilities Plugin
 * ------------------------------------------------------------
 *
 * Project:       Fixium
 * Version:       0.0.1-beta.0.6
 * Author:        HighLightsOfficial, Mateo Collar
 * GitHub:        https://github.com/HighLightsOfficial/Fixium
 * Description:   Performance enhancements, world/entity fixes, and server utilities
 * License:       MIT License (https://opensource.org/licenses/MIT)
 * ------------------------------------------------------------
 */

namespace Mqtz\modules;

use Mqtz\Main;
use Mqtz\Logger;
use Mqtz\Tasks\AutoCleanerT;

class AutoCleaner {

    public static function init() {
        $plugin = Main::getInstance();
        $config = $plugin->getConfig();

        if (!$config->getNested("optimize.auto-cleanup", true)) {
            if ($config->get("log-activated-modules", true)) {
                Logger::debug("Module skipped: AutoCleaner is disabled in config.");
            }
            return;
        }

        $interval = intval($config->getNested("optimize.cleanup-interval", 300));

        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(new AutoCleanerT(), $interval * 20);

        if ($config->get("log-activated-modules", true)) {
            Logger::info("Module loaded: AutoCleaner");
        }
    }
}