<?php
/*
 * ------------------------------------------------------------
 * Fixium - Minecraft PE Server Optimizer & Utilities Plugin
 * ------------------------------------------------------------
 *
 * Project:       Fixium
 * Version:       0.0.1-beta.0.6
 * Author:        HighLightsOfficial, Mateo Collar
 * GitHub:        https://github.com/HighLightsOfficial/Fixium
 * Description:   Performance enhancements, world/entity fixes, and server utilities
 * License:       MIT License (https://opensource.org/licenses/MIT)
 * ------------------------------------------------------------
 */

namespace Mqtz\modules;

use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockUpdateEvent;
use Mqtz\Tasks\LULTask;
use Mqtz\{Logger, Main};

class LightUpdateLimiter implements Listener {

    private static $lightUpdateCount = 0;
    private static $lightUpdateLimit = 100;

    public static function init() {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("Fixium");

        Server::getInstance()->getPluginManager()->registerEvents(new self(), $plugin);
        Server::getInstance()->getScheduler()->scheduleRepeatingTask(new LULTask($plugin), 1);

        if ($plugin->getConfig()->get("log-activated-modules", true)) {
            Logger::info("Module loaded: LightUpdateLimiter.");
        }
    }

    public static function canUpdateLight() {
        return self::$lightUpdateCount < self::$lightUpdateLimit;
    }

    public static function registerLightUpdate() {
        self::$lightUpdateCount++;
    }

    public static function resetLightCount() {
        self::$lightUpdateCount = 0;
    }

    public function onBlockUpdate(BlockUpdateEvent $event) {
        if (!self::canUpdateLight()) {
            $event->cancel();
            return;
        }
        self::registerLightUpdate();
    }
}