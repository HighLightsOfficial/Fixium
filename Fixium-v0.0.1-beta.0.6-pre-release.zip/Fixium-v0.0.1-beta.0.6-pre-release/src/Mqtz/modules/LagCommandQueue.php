<?php
/*
 * ------------------------------------------------------------
 * Fixium - Minecraft PE Server Optimizer & Utilities Plugin
 * ------------------------------------------------------------
 *
 * Project:       Fixium
 * Version:       0.0.1-beta.0.6
 * Author:        HighLightsOfficial, Mateo Collar
 * GitHub:        https://github.com/HighLightsOfficial/Fixium
 * Description:   Performance enhancements, world/entity fixes, and server utilities
 * License:       MIT License (https://opensource.org/licenses/MIT)
 * ------------------------------------------------------------
 */

namespace Mqtz\modules;

use pocketmine\event\Listener;
use pocketmine\event\server\ServerCommandEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\Player;
use pocketmine\scheduler\CallbackTask;
use pocketmine\command\ConsoleCommandSender;
use Mqtz\Main;
use Mqtz\Logger;

class LagCommandQueue implements Listener {

    /** @var array */
    private static $queue = [];

    /** @var float */
    private static $lastTickTime = 0;

    public static function init() {
        $plugin = Main::getInstance();
        $config = $plugin->getConfig();

        if (!$config->getNested("modules.lag-command-queue", true)) {
            if ($config->get("log-activated-modules", true)) {
                Logger::debug("Module skipped: LagCommandQueue is disabled in config.");
            }
            return;
        }

        $plugin->getServer()->getPluginManager()->registerEvents(new self(), $plugin);
        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(new CallbackTask([self::class, "processQueue"]), 5);

        if ($config->get("log-activated-modules", true)) {
            Logger::info("Module loaded: LagCommandQueue.");
        }
    }

    public function onPlayerCommand(PlayerCommandPreprocessEvent $event) {
        $player = $event->getPlayer();
        $message = $event->getMessage();

        if (substr($message, 0, 1) !== "/") return;
        $cmd = substr($message, 1);

        $server = Main::getInstance()->getServer();
        $tps = $server->getTicksPerSecond();

        if ($this->shouldQueue()) {
            $event->setCancelled(true);
            self::$queue[] = ["cmd" => $cmd, "executor" => $player];
            Logger::warning("Queued heavy command from player: {$player->getName()} — /{$cmd} | TPS: $tps");
        }
    }

    public function onConsoleCommand(ServerCommandEvent $event) {
        $cmd = $event->getCommand();

        $server = Main::getInstance()->getServer();
        $tps = $server->getTicksPerSecond();

        if ($this->shouldQueue()) {
            $event->setCancelled(true);
            self::$queue[] = ["cmd" => $cmd, "executor" => null];
            Logger::warning("Queued heavy command from console — /{$cmd} | TPS: $tps");
        }
    }

    private function shouldQueue() {
        $server = Main::getInstance()->getServer();
        $tps = $server->getTicksPerSecond();

        return ($tps < 14 || (microtime(true) - self::$lastTickTime) > 0.2);
    }

    public static function processQueue() {
        $server = Main::getInstance()->getServer();

        if (empty(self::$queue)) return;

        $tps = $server->getTicksPerSecond();
        if ($tps < 15) return;

        $item = array_shift(self::$queue);

        $start = microtime(true);

        if ($item["executor"] instanceof Player) {
            $server->dispatchCommand($item["executor"], $item["cmd"]);
        } else {
            $console = new ConsoleCommandSender();
            $server->dispatchCommand($console, $item["cmd"]);
        }

        $end = microtime(true);
        $elapsed = round(($end - $start) * 1000, 2);

        Logger::info("Executed queued command: /{$item['cmd']} | Execution time: {$elapsed} ms | TPS: $tps");
    }
}