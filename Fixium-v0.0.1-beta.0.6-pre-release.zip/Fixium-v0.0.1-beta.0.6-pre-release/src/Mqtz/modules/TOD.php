<?php
/*
 * ------------------------------------------------------------
 * Fixium - Minecraft PE Server Optimizer & Utilities Plugin
 * ------------------------------------------------------------
 *
 * Project:       Fixium
 * Version:       0.0.1-beta.0.6
 * Author:        HighLightsOfficial, Mateo Collar
 * GitHub:        https://github.com/HighLightsOfficial/Fixium
 * Description:   Performance enhancements, world/entity fixes, and server utilities
 * License:       MIT License (https://opensource.org/licenses/MIT)
 * ------------------------------------------------------------
 */

namespace Mqtz\modules;

use Mqtz\Tasks\TODTask;
use Mqtz\Main;
use Mqtz\Logger;

class TOD {

    public static function init(Main $plugin) {
        $plugin->getServer()->getScheduler()->scheduleDelayedTask(new TODTask($plugin), 20);

        if ($plugin->getConfig()->get("log-activated-modules", true)) {
            Logger::info("Module loaded: TOD (Time-of-Day task scheduled).");
        }
    }
}