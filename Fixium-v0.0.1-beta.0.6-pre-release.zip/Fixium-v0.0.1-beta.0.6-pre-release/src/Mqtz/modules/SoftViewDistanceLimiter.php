<?php
/*
 * ------------------------------------------------------------
 * Fixium - Minecraft PE Server Optimizer & Utilities Plugin
 * ------------------------------------------------------------
 *
 * Project:       Fixium
 * Version:       0.0.1-beta.0.6
 * Author:        HighLightsOfficial, Mateo Collar
 * GitHub:        https://github.com/HighLightsOfficial/Fixium
 * Description:   Performance enhancements, world/entity fixes, and server utilities
 * License:       MIT License (https://opensource.org/licenses/MIT)
 * ------------------------------------------------------------
 */

namespace Mqtz\modules;

use pocketmine\Player;
use pocketmine\scheduler\Task;
use Mqtz\Logger;
use Mqtz\Main;

class SoftViewDistanceLimiter {

    /** @var Main */
    private $plugin;

    /** @var int */
    private $afkThreshold;

    /** @var int */
    private $checkInterval;

    /** @var int */
    private $reducedDistance;

    /** @var array<string, array{x: int, y: int, z: int, ticks: int, isAfk: bool}> */
    private $playerStates = [];

    public function __construct(Main $plugin){
        $this->plugin = $plugin;

        $config = $plugin->getConfig()->get("soft_view_distance") ?? [];

        $this->afkThreshold = $config["afk_threshold_ticks"] ?? 200;
        $this->checkInterval = $config["check_interval_ticks"] ?? 40;
        $this->reducedDistance = $config["reduced_chunk_distance"] ?? 2;

        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(new class($this) extends Task {
            private $module;
            public function __construct(SoftViewDistanceLimiter $module){
                $this->module = $module;
            }
            public function onRun($currentTick){
                $this->module->tick();
            }
        }, $this->checkInterval);

        if ($plugin->getConfig()->get("log-activated-modules", true)) {
            Logger::info("Module loaded: SoftViewDistanceLimiter. Threshold: {$this->afkThreshold} ticks, Distance: {$this->reducedDistance} chunks.");
        }
    }

    public function tick(){
        foreach($this->plugin->getServer()->getOnlinePlayers() as $player){
            if($player->hasPermission("fixium.bypass.svdl")) continue;

            $name = strtolower($player->getName());

            $x = (int) $player->getX();
            $y = (int) $player->getY();
            $z = (int) $player->getZ();

            if(!isset($this->playerStates[$name])){
                $this->playerStates[$name] = ["x"=>$x,"y"=>$y,"z"=>$z,"ticks"=>0,"isAfk"=>false];
                continue;
            }

            $data = &$this->playerStates[$name];

            if($data["x"] === $x && $data["y"] === $y && $data["z"] === $z){
                $data["ticks"] += $this->checkInterval;
                if(!$data["isAfk"] && $data["ticks"] >= $this->afkThreshold){
                    $data["isAfk"] = true;
                    $this->applyReducedView($player);
                    if ($this->plugin->getConfig()->get("log-activated-modules", true)) {
                        Logger::info("SoftViewDistanceLimiter: Player '{$name}' is now AFK. View distance reduced.");
                    }
                }
            } else {
                if($data["isAfk"] && $this->plugin->getConfig()->get("log-activated-modules", true)){
                    Logger::info("SoftViewDistanceLimiter: Player '{$name}' is now active. View distance restored.");
                }
                $data["x"] = $x;
                $data["y"] = $y;
                $data["z"] = $z;
                $data["ticks"] = 0;
                $data["isAfk"] = false;
                $this->restoreChunks($player);
            }
        }
    }

    private function applyReducedView(Player $player){
        $centerX = (int) $player->getX() >> 4;
        $centerZ = (int) $player->getZ() >> 4;
        $level = $player->getLevel();

        foreach($level->getChunks() as $chunk){
            $chunkX = $chunk->getX();
            $chunkZ = $chunk->getZ();
            $distance = max(abs($chunkX - $centerX), abs($chunkZ - $centerZ));
            if($distance > $this->reducedDistance) $level->unloadChunk($chunkX, $chunkZ, false);
        }
    }

    private function restoreChunks(Player $player){
        $level = $player->getLevel();
        $chunkX = (int) $player->getX() >> 4;
        $chunkZ = (int) $player->getZ() >> 4;
        $radius = 4;
        for($x=-$radius;$x<=$radius;$x++){
            for($z=-$radius;$z<=$radius;$z++){
                $level->loadChunk($chunkX+$x,$chunkZ+$z,true);
            }
        }
    }
}