<?php
/*
 * ------------------------------------------------------------
 * Fixium - Minecraft PE Server Optimizer & Utilities Plugin
 * ------------------------------------------------------------
 *
 * Project:       Fixium
 * Version:       0.0.1-beta.0.5
 * Author:        HighLightsOfficial
 * GitHub:        https://github.com/HighLightsOfficial/Fixium
 * Description:   Performance enhancements, world/entity fixes, and server utilities
 * License:       MIT License (https://opensource.org/licenses/MIT)
 *                Permission is hereby granted, free of charge, to any person
 *                obtaining a copy of this software and associated documentation
 *                files (the "Software"), to deal in the Software without
 *                restriction, including without limitation the rights to use,
 *                copy, modify, merge, publish, distribute, sublicense, and/or
 *                sell copies of the Software, subject to the conditions in the
 *                LICENSE file.
 * ------------------------------------------------------------
 */
namespace Mqtz\Tasks;

use pocketmine\scheduler\Task;
use pocketmine\Server;
use Mqtz\Main;
use Mqtz\Logger;

class TODTask extends Task {

    public function onRun($tick) {
        $config = Main::getInstance()->getConfig();
        $threshold = $config->getNested("detectors.plugin-load-threshold", 100);

        $plugins = Server::getInstance()->getPluginManager()->getPlugins();

        $times = [];

        foreach ($plugins as $plugin) {
            $name = $plugin->getName();

            $start = microtime(true);
            if (method_exists($plugin, "onLoad")) {
                $plugin->onLoad(); // If this causes errors in plugins, please contact the HighLights support team.
            }
            $end = microtime(true);

            $ms = round(($end - $start) * 1000, 2);
            $times[$name] = $ms;

            if ($ms >= $threshold) {
                Logger::warning("⏱ Plugin '$name' took $ms ms to load. Possible startup lag.");
            }
        }

        arsort($times);

        $top = array_slice($times, 0, 5, true);
        $count = count($top);
        if ($count < 5) {
            for ($i = $count + 1; $i <= 5; $i++) {
                $top["N/A #$i"] = 0;
            }
        }

        Logger::info("⏱ Top Slow Plugins:");
        $rank = 1;
        foreach ($top as $pluginName => $timeMs) {
            $timeDisplay = $timeMs > 0 ? "$timeMs ms" : "no data";
            Logger::info("  $rank. $pluginName » $timeDisplay");
            $rank++;
        }

        Logger::info("TickOverloadDetector finished timing all plugins.");
    }
}