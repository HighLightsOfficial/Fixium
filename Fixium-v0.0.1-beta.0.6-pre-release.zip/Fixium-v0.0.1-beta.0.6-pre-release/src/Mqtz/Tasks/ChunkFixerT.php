<?php
/*
 * ------------------------------------------------------------
 * Fixium - Minecraft PE Server Optimizer & Utilities Plugin
 * ------------------------------------------------------------
 *
 * Project:       Fixium
 * Version:       0.0.1-beta.0.5
 * Author:        HighLightsOfficial
 * GitHub:        https://github.com/HighLightsOfficial/Fixium
 * Description:   Performance enhancements, world/entity fixes, and server utilities
 * License:       MIT License (https://opensource.org/licenses/MIT)
 *                Permission is hereby granted, free of charge, to any person
 *                obtaining a copy of this software and associated documentation
 *                files (the "Software"), to deal in the Software without
 *                restriction, including without limitation the rights to use,
 *                copy, modify, merge, publish, distribute, sublicense, and/or
 *                sell copies of the Software, subject to the conditions in the
 *                LICENSE file.
 * ------------------------------------------------------------
 */
namespace Mqtz\Tasks;

use pocketmine\scheduler\Task;
use pocketmine\level\Level;
use pocketmine\Server;
use Mqtz\Logger;

class ChunkFixerT extends Task {

    public function onRun($currentTick) {
        $beforeReal = memory_get_usage(false);
        $beforeAlloc = memory_get_usage(true);

        $unloaded = 0;

        foreach (Server::getInstance()->getLevels() as $level) {
            foreach ($level->getChunks() as $chunk) {
                $chunkX = $chunk->getX();
                $chunkZ = $chunk->getZ();

                if ($level->isChunkLoaded($chunkX, $chunkZ)) {
                    if (count($level->getChunkPlayers($chunkX, $chunkZ)) === 0) {
                        $level->unloadChunk($chunkX, $chunkZ, true);
                        $unloaded++;
                    }
                }
            }
        }

        gc_collect_cycles();

        $afterReal = memory_get_usage(false);
        $afterAlloc = memory_get_usage(true);

        $freedReal = round(($beforeReal - $afterReal) / 1024 / 1024, 2);
        $freedAlloc = round(($beforeAlloc - $afterAlloc) / 1024 / 1024, 2);

        Logger::info("ChunkFreezeFix unloaded $unloaded unused chunk(s).");
        Logger::info("Memory freed (real): $freedReal MB (Before: " . round($beforeReal / 1024 / 1024, 2) . " MB | After: " . round($afterReal / 1024 / 1024, 2) . " MB)");
        Logger::info("Memory freed (allocated): $freedAlloc MB (Before: " . round($beforeAlloc / 1024 / 1024, 2) . " MB | After: " . round($afterAlloc / 1024 / 1024, 2) . " MB)");
        Logger::warning("Note: PHP may retain allocated memory after chunk unload. Actual memory freed could be higher.");
    }
}