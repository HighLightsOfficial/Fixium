<?php
namespace Mqtz;

class Logger {

    public static function log($message) {
        self::info($message);
    }

    public static function info($message) {
        $time = date("Y-m-d H:i:s");
        $formatted = "§8[§bFixium§8] §7[$time] §f» §a$message";

        $main = Main::getInstance();
        if ($main !== null) {
            $main->getLogger()->info($formatted);

            $logDir = $main->getDataFolder() . "logs/";
            if (!is_dir($logDir)) {
                @mkdir($logDir, 0777, true);
            }

            $logLine = "[Fixium][INFO] [$time] >> $message";
            @file_put_contents($logDir . "logs.txt", $logLine . "\n", FILE_APPEND);
        }
    }

    public static function warning($message) {
        $time = date("Y-m-d H:i:s");
        $formatted = "§8[§bFixium§8] §7[$time] §f» §e$message";

        $main = Main::getInstance();
        if ($main !== null) {
            $main->getLogger()->warning($formatted);

            $logDir = $main->getDataFolder() . "logs/";
            if (!is_dir($logDir)) {
                @mkdir($logDir, 0777, true);
            }

            $logLine = "[Fixium][WARNING] [$time] >> $message";
            @file_put_contents($logDir . "logs.txt", $logLine . "\n", FILE_APPEND);
        }
    }
}