<?php

namespace Mqtz\modules;

use pocketmine\Server;
use pocketmine\scheduler\CallbackTask;
use pocketmine\plugin\Plugin;
use Mqtz\Logger;

class FixiumProfiler {

    public static function init(Plugin $plugin) {
        $config = $plugin->getConfig();
        $seconds = $config->getNested("profiler.snapshot-interval-seconds", 60);
        $interval = max(20, $seconds * 20);

        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(
            new CallbackTask([self::class, "snapshot"]),
            $interval
        );

        Logger::log("FixiumProfiler enabled. Generating snapshots every $seconds seconds.");
    }

    public static function snapshot() {
        $server = Server::getInstance();

        $memory = round(memory_get_usage(true) / 1024 / 1024, 2);
        $players = count($server->getOnlinePlayers());
        $entities = 0;

        foreach ($server->getLevels() as $level) {
            $entities += count($level->getEntities());
        }

        $tps = $server->getTicksPerSecond();
        $timestamp = date("Y-m-d H:i:s");
        $filenameTime = date("Ymd_His");

        $encoded = base64_encode(json_encode([
            "t" => $timestamp,
            "m" => $memory,
            "e" => $entities,
            "p" => $players,
            "tps" => $tps
        ]));

        $snapshot = "[FixiumSnapshot]\n";
        $snapshot .= "timestamp: $timestamp\n";
        $snapshot .= "memory: {$memory}MB\n";
        $snapshot .= "entities: $entities\n";
        $snapshot .= "chunks: N/A (unsupported in 0.15.10)\n";
        $snapshot .= "players: $players\n";
        $snapshot .= "tps: $tps\n";
        $snapshot .= "encoded: $encoded\n";
        $snapshot .= "---END SNAPSHOT---\n";

        $dir = "plugins/Fixium/snapshots/";
        if (!is_dir($dir)) {
            @mkdir($dir, 0777, true);
        }

        $filePath = $dir . "snapshot_" . $filenameTime . ".fxm";
        file_put_contents($filePath, $snapshot);
    }
}