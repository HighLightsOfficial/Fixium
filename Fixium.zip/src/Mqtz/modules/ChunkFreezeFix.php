<?php

namespace Mqtz\modules;

use pocketmine\scheduler\Task;
use pocketmine\Player;
use Mqtz\Main;
use Mqtz\Logger;

class ChunkFreezeFix {

    public static function init() {
        $plugin = Main::getInstance();
        $config = $plugin->getConfig();

        if (!$config->getNested("optimize.chunk-unfreeze", true)) {
            Logger::log("ChunkFreezeFix is disabled in config.");
            return;
        }

        $interval = $config->getNested("optimize.chunk-unfreeze-interval", 300);
        $plugin->getServer()->getScheduler()->scheduleRepeatingTask(new \Mqtz\Tasks\ChunkFixerT(), $interval * 20);
        Logger::log("ChunkFreezeFix enabled, interval: {$interval}s.");
    }
}