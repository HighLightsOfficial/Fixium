<?php

namespace Mqtz\modules;

use Mqtz\Tasks\TODTask;
use Mqtz\Main;

class TOD {

    public static function init(Main $plugin) {
        $plugin->getServer()->getScheduler()->scheduleDelayedTask(new TODTask($plugin), 20);
    }
}