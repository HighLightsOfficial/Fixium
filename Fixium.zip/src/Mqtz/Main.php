<?php

namespace Mqtz;

use pocketmine\plugin\PluginBase;
use Mqtz\Logger;

class Main extends PluginBase {

    private static $instance;

    public function onLoad() {
        self::$instance = $this;
    }

    public function onEnable() {
        @mkdir($this->getDataFolder() . "logs");
        @mkdir($this->getDataFolder() . "resources");

        $this->saveResource("config.yml");

        Logger::log("Fixium has been successfully enabled.(v0.0.1-beta.0.2)");
        \Mqtz\modules\WorldLoader::loadWorlds();
        \Mqtz\modules\EntityFix::init();
        \Mqtz\modules\AutoCleaner::init();
        \Mqtz\modules\ChunkFreezeFix::init();
        \Mqtz\modules\TOD::init($this);
        \Mqtz\modules\FixiumProfiler::init($this);
        
        $this->getCommand("fixium")->setExecutor(new \Mqtz\Fixium());
    }

    public function onDisable() {
        Logger::log("Fixium has been disabled.");
    }
    public static function getInstance() {
        return self::$instance;
    }
}