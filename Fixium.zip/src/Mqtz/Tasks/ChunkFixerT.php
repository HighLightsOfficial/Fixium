<?php

namespace Mqtz\Tasks;

use pocketmine\scheduler\Task;
use pocketmine\level\Level;
use pocketmine\Server;
use Mqtz\Logger;

class ChunkFixerT extends Task {

    public function onRun($currentTick) {
        $unloaded = 0;

        foreach (Server::getInstance()->getLevels() as $level) {
            foreach ($level->getChunks() as $chunk) {
                $chunkX = $chunk->getX();
                $chunkZ = $chunk->getZ();

                if ($level->isChunkLoaded($chunkX, $chunkZ)) {
                    if (count($level->getChunkPlayers($chunkX, $chunkZ)) === 0) {
                        $level->unloadChunk($chunkX, $chunkZ, true);
                        $unloaded++;
                    }
                }
            }
        }

        Logger::log("ChunkFreezeFix unloaded $unloaded unused chunk(s).");
    }
}