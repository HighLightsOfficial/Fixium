<?php

namespace Mqtz\Tasks;

use pocketmine\scheduler\Task;
use pocketmine\entity\Entity;
use pocketmine\entity\Item;
use pocketmine\entity\Arrow;
use pocketmine\entity\Snowball;
use pocketmine\entity\Egg;
use pocketmine\entity\Living;
use pocketmine\Player;
use pocketmine\Server;

use Mqtz\Logger;

class AutoCleanerT extends Task {

    public function onRun($currentTick) {
        $removed = 0;
        $skipped = 0;

        foreach (Server::getInstance()->getLevels() as $level) {
            foreach ($level->getEntities() as $entity) {
                $class = get_class($entity);

                if (
                    $entity instanceof Item or
                    $entity instanceof Arrow or
                    $entity instanceof Snowball or
                    $entity instanceof Egg or
                    (
                        $entity instanceof Living and 
                        !($entity instanceof Player) and 
                        $entity->getNameTag() === ""
                    )
                ) {
                    if (method_exists($entity, "close") && (!method_exists($entity, "isClosed") || !$entity->isClosed())) {
                        $entity->close();
                        $removed++;
                    }
                } else {
                    $skipped++;
                }
            }
        }

        Logger::log("AutoCleaner removed $removed unused entity(ies).");
        Logger::log("AutoCleaner skipped $skipped entity(ies) (named or active).");
    }
}