<?php

namespace Mqtz\Tasks;

use pocketmine\scheduler\Task;
use pocketmine\Server;
use Mqtz\Main;
use Mqtz\Logger;

class TODTask extends Task {

    public function onRun($tick) {
        $config = Main::getInstance()->getConfig();
        $threshold = $config->getNested("detectors.plugin-load-threshold", 100);

        $plugins = Server::getInstance()->getPluginManager()->getPlugins();

        $times = [];

        foreach ($plugins as $plugin) {
            $name = $plugin->getName();

            $start = microtime(true);
            if (method_exists($plugin, "onLoad")) {
                $plugin->onLoad(); // If this causes errors in plugins, please contact the HighLights support team.
            }
            $end = microtime(true);

            $ms = round(($end - $start) * 1000, 2);
            $times[$name] = $ms;

            if ($ms >= $threshold) {
                Logger::log("⏱ Plugin '$name' took $ms ms to load. Possible startup lag.");
            }
        }

        arsort($times);

        $top = array_slice($times, 0, 5, true);
        $count = count($top);
        if ($count < 5) {
            for ($i = $count + 1; $i <= 5; $i++) {
                $top["N/A #$i"] = 0;
            }
        }

        Logger::log("⏱ Top Slow Plugins:");
        $rank = 1;
        foreach ($top as $pluginName => $timeMs) {
            $timeDisplay = $timeMs > 0 ? "$timeMs ms" : "no data";
            Logger::log("  $rank. $pluginName » $timeDisplay");
            $rank++;
        }

        Logger::log("TickOverloadDetector finished timing all plugins.");
    }
}