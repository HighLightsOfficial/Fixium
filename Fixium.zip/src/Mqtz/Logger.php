<?php

namespace Mqtz;

class Logger {

    public static function log($message) {
        $time = date("Y-m-d H:i:s");
        $formatted = "§8[§bFixium§8] §7[$time] §f» §e$message";

        Main::getInstance()->getLogger()->info($formatted);

        $logLine = "[Fixium] [$time] >> $message";
        file_put_contents(Main::getInstance()->getDataFolder() . "logs/logs.txt", $logLine . "\n", FILE_APPEND);
    }
}